package com.pc.screen;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class test1 {

	public static String sheetname = "test1";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	private WebDriver driver = ManagerDriver.getInstance().getWebDriver();
	
	public Boolean SCRtest1() throws Exception
	{		
		Boolean status = common.OpenApp();
		//Boolean status = true;
		status = common.ClassComponent(sheetname, Common.o);
		if(!status)
		{
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "test1 Should be Successful","Search User was not successfully executed", "FAIL");
			return false;
		}
		else
		{
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "test1 Should be Successful","Search User was successfully executed", "PASS");
		}
		
		return status;
	}
}
